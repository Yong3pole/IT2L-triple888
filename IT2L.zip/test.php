import React from "react";
import { Button } from "@mui/material";
import "./style.css";

export const Slide = () => {
return (
<div className="slide">
    <div className="overlap-group-wrapper">
        <div className="overlap-group">
            <Button color="default" size="medium" variant="outlined">
                Home
            </Button>
            <Button size="medium" variant="outlined">
                User Management
            </Button>
            <Button size="medium" variant="outlined">
                Stocks
            </Button>
            <Button color="default" size="medium" variant="outlined">
                Logout
            </Button>
        </div>
    </div>
</div>
);
};