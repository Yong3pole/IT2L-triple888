<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prod_id = $_POST['prod_id'];
    $prod_name = $_POST['prod_name'];
    $prod_brand = $_POST['prod_brand'];
    $prod_manufacturer = $_POST['prod_manufacturer'];
    $prod_category = $_POST['prod_category'];
    $prod_form = $_POST['prod_form'];
    $prod_dosage = $_POST['prod_dosage'];
    $prod_price = $_POST['prod_price'];

    // Update the medicine in the database
    $query = "UPDATE product SET 
                prod_name = ?, 
                prod_brand = ?, 
                prod_manufacturer = ?, 
                prod_category = ?, 
                prod_form = ?, 
                prod_dosage = ?, 
                prod_price = ?
              WHERE prod_id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssssssdi', $prod_name, $prod_brand, $prod_manufacturer, $prod_category, $prod_form, $prod_dosage, $prod_price, $prod_id);

    if ($stmt->execute()) {
        // Success message
        $_SESSION['success_editprod'] = "Product updated successfully!";
    } else {
        // Error handling
        $_SESSION['error_editprod'] = "Error updating product!";
    }

    header('Location: product_list.php');
    exit();
}
