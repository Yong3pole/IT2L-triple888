<?php
session_start();
require '../db.php'; // Include your database connection

// Assume you have a user ID stored in the session
$user_id = $_SESSION['user_id'];

// Fetch user data
$sql = "SELECT * FROM user WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if user data was found
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Extract user data for use in the form
    $first_name = $user['first_name'];
    $last_name = $user['last_name'];
    $birthday = $user['birthday'];
    $phone = $user['phone'];
    $email = $user['email'];
    $username = $user['username'];
    $role = $user['role'];
    $status = $user['status']; // This might be a boolean
} else {
    die("User not found");
}
$stmt->close();
$conn->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['birthday'], $_POST['phone'], $_POST['email'], $_POST['username'])) {
    // Validate input here
    $birthday = $_POST['birthday'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $username = $_POST['username'];

    // Update user in the database
    $update_sql = "UPDATE user SET birthday = ?, phone = ?, email = ?, username = ? WHERE user_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssssi", $birthday, $phone, $email, $username, $user_id);
    $update_stmt->execute();

    // Redirect or display a success message
    $_SESSION['success_message'] = "Profile updated successfully!";
    header("Location: user_profile.php"); // Redirect to the same page
    exit();
}


?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Profile</title>
    <!-- Bootstrap CSS -->
    <link href="../bootstrap/css/bootstrap.css" rel="stylesheet">
    <style>
        .profile-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        h2 {
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }
    </style>

    <script>
        $(document).ready(function() {
            $("#editButton").click(function() {
                // Enable input fields
                $("#full_name, #birthday, #phone, #email, #username").prop("disabled", false);
                // Show Save button
                $("#saveButton").show();
                // Change Edit button to Cancel
                $(this).text($(this).text() === 'Edit' ? 'Cancel' : 'Edit');

                // If Cancel is clicked, reset input fields and disable them
                if ($(this).text() === 'Cancel') {
                    $(this).data('editing', true);
                } else {
                    $(this).data('editing', false);
                    // Reset input fields to their original values (if needed)
                    $("#full_name").val("<?php echo htmlspecialchars($first_name . ' ' . $last_name); ?>");
                    $("#birthday").val("<?php echo htmlspecialchars($birthday); ?>");
                    $("#phone").val("<?php echo htmlspecialchars($phone); ?>");
                    $("#email").val("<?php echo htmlspecialchars($email); ?>");
                    $("#username").val("<?php echo htmlspecialchars($username); ?>");
                    // Disable input fields again
                    $("#full_name, #birthday, #phone, #email, #username").prop("disabled", true);
                    // Hide Save button
                    $("#saveButton").hide();
                }
            });
        });
    </script>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Triple 888 Pharmacy System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="user_home.php">Home</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_sales.php">Sales</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_inventory.php">Inventory</a> <!-- Update this line -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_profile.php">Profile <span class="sr-only">(current)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="profile-container">
            <h2>User Profile</h2>
            <form id="profileForm">
                <div class="form-group">
                    <label for="full_name">Full Name:</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo htmlspecialchars($first_name . ' ' . $last_name); ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="birthday">Birthday:</label>
                    <input type="date" id="birthday" name="birthday" class="form-control" value="<?php echo htmlspecialchars($birthday); ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="phone">Phone:</label>
                    <input type="text" id="phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($phone); ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="role">Role:</label>
                    <input type="text" id="role" name="role" class="form-control" value="<?php echo htmlspecialchars($role); ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="status">Status:</label>
                    <input type="text" id="status" name="status" class="form-control" value="<?php echo $status ? 'Active' : 'Inactive'; ?>" disabled>
                </div>

                <button type="button" id="editButton" class="btn btn-primary">Edit</button>
                <button type="submit" id="saveButton" class="btn btn-success" style="display: none;">Save Changes</button>
            </form>

            <h3 class="mt-4">Change Password</h3>
            <form id="changePasswordForm">
                <div class="form-group">
                    <label for="current_password">Current Password:</label>
                    <input type="password" id="current_password" name="current_password" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="new_password">New Password:</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="confirm_new_password">Confirm New Password:</label>
                    <input type="password" id="confirm_new_password" name="confirm_new_password" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-danger">Change Password</button>
            </form>

            <button id="logoutButton" class="btn btn-secondary mt-3">Logout</button>
        </div>

    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="../jquery/jquery-3.7.1.min.js"></script>
    <script src="../node_modules/@popperjs/core/lib/popper-lite.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>

</html>