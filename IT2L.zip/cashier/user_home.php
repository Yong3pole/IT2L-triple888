<?php
// user_home.php (POS System)
session_start();
// Check if the user is logged in and has the 'User' role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'User') {
    // If not logged in or not a user, redirect to login page
    header("Location: ../login.php");
    exit();
}
// Include database connection
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db.php';

// Query to fetch available items from the inventory table
$sql = "SELECT i.prod_id, m.prod_name, m.prod_price, i.quantity 
        FROM inventory i 
        INNER JOIN product m ON i.prod_id = m.prod_id
        WHERE i.quantity > 0";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS System</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="cashier_css/cashier.css">
</head>

<body style="background-color: #d8e5cc;">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Triple 888 Pharmacy System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="user_home.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_sales.php">Sales</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_inventory.php">Inventory</a> <!-- Update this line -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Discount Modal -->
    <div class="modal fade" id="discountModal" tabindex="-1" aria-labelledby="discountModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="discountModalLabel">Apply Senior Citizen Discount</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="senior-name" class="form-label">Senior Citizen Name</label>
                        <input type="text" class="form-control" id="senior-name" placeholder="Enter Senior Citizen Name">
                    </div>
                    <div class="mb-3">
                        <label for="senior-contact" class="form-label">Contact Number</label>
                        <input type="text" class="form-control" id="senior-contact" placeholder="Enter Contact Number">
                    </div>
                    <div class="mb-3">
                        <label for="discount-id" class="form-label">Senior Citizen ID</label>
                        <input type="text" class="form-control" id="discount-id" placeholder="Enter Discount ID">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="apply-discount-confirm">Apply Discount</button>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <?php
        if (isset($_SESSION['purchase_complete'])) {
            echo "<div class='alert alert-success text-center' style='position: absolute; left: 50%; transform: translateX(-50%); z-index: 1000; width: 50%;'>
            " . $_SESSION['purchase_complete'] . "
            <form action='user_home.php' method='POST' style='display:inline;'>
                <button type='submit' class='btn-close' aria-label='Close'></button>
                <input type='hidden' name='dismiss_alert' value='1'>
            </form>
        </div>";
            unset($_SESSION['purchase_complete']);
        }
        ?>

        <div class="row">
            <!-- Items Area (Left side) -->
            <div class="col-md-8">
                <div class="row align-items-center mb-3">
                    <div class="col-md-6">
                        <h2 class="m-0">Select Products</h2>
                    </div>
                    <div class="col-md-6">
                        <input type="text" id="search-input" placeholder="Search products..." class="form-control">
                    </div>
                </div>
                <div class="items-area">
                    <table class="table table-bordered table-hover" id="items-table">
                        <thead class="thead-dark">
                            <tr>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Quantity Available</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '
                        <tr>
                            <td>' . htmlspecialchars($row['prod_name']) . '</td>
                            <td>₱ ' . number_format($row['prod_price'], 2) . '</td>
                            <td>' . intval($row['quantity']) . '</td>
                            <td>
                                <button class="btn btn-info add-to-cart" 
                                        data-id="' . $row['prod_id'] . '" 
                                        data-name="' . htmlspecialchars($row['prod_name']) . '" 
                                        data-price="' . $row['prod_price'] . '">Add</button>
                            </td>
                        </tr>';
                                }
                            } else {
                                echo '<tr><td colspan="4">No items available in stock.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php include 'checkout_sidebar.php'; ?>
        </div>
    </div>

    <script>
        document.getElementById('search-input').addEventListener('keyup', function() {
            var input = this.value.toLowerCase();
            var table = document.getElementById('items-table');
            var rows = table.getElementsByTagName('tr');

            for (var i = 1; i < rows.length; i++) { // Start from 1 to skip the header row
                var cells = rows[i].getElementsByTagName('td');
                var rowContainsSearchTerm = false;

                for (var j = 0; j < cells.length; j++) {
                    if (cells[j]) {
                        var cellText = cells[j].textContent || cells[j].innerText;
                        if (cellText.toLowerCase().indexOf(input) > -1) {
                            rowContainsSearchTerm = true;
                            break; // No need to check further cells
                        }
                    }
                }

                if (rowContainsSearchTerm) {
                    rows[i].style.display = ""; // Show the row
                } else {
                    rows[i].style.display = "none"; // Hide the row
                }
            }
        });
    </script>

    <script src="../node_modules/@popperjs/core/lib/popper-lite.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>



</body>

</html>