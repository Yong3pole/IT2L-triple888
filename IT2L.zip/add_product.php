<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $prod_name = $_POST['prod_name'];
    $prod_brand = $_POST['prod_brand'];
    $prod_manufacturer = $_POST['prod_manufacturer'];
    $prod_category = $_POST['prod_category'];
    $prod_form = $_POST['prod_form'];
    $prod_dosage = $_POST['prod_dosage'];
    $prod_price = $_POST['prod_price'];
    $prod_archive = 1; // Automatically set prod_archive to 1

    $stmt = $conn->prepare("INSERT INTO product (prod_name, prod_brand, prod_manufacturer, prod_category, prod_form, prod_dosage, prod_price, prod_archive) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssdi", $prod_name, $prod_brand, $prod_manufacturer, $prod_category, $prod_form, $prod_dosage, $prod_price, $prod_archive);

    if ($stmt->execute()) {
        // Set success message in the session
        $_SESSION['success_addprod'] = "Product added successfully!";
    } else {
        $_SESSION['success_addprod'] = "Error: Could not add Product.";
    }

    // Redirect to the same page to avoid form resubmission
    header("Location: product_list.php");
    exit();
}
