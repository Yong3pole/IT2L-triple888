<?php
// user_management.php
session_start();
include 'db.php';
include 'sidebar.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="css/bootstrapstyle.css"> <!-- Link to compiled CSS -->
    <link rel="stylesheet" href="css/sidebar.css"> <!-- Link to sidebar CSS -->
</head>

<body>
    <div class="content" style="margin-left: 300px; margin-top: 100px; margin-right: 50px;">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>User Management</h2>
            <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#addUserModal" style="min-width: 130px;">Add User</button>
        </div>
        <table class="table table-bordered">
            <caption class="caption-top">List of Users</caption>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM user";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($user = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$user['first_name']}</td>
                            <td>{$user['last_name']}</td>
                            <td>{$user['phone']}</td>
                            <td>{$user['email']}</td>
                            <td>{$user['username']}</td>
                            <td>{$user['role']}</td>
                            <td>" . ($user['status'] ? 'Active' : 'Inactive') . "</td>
                            <td>";
                        // Allow admins to edit other admins but disable role/status fields in the modal
                        echo "<a href='#' class='btn btn-warning btn-sm' data-bs-toggle='modal' data-bs-target='#editModal' 
                            data-id='{$user['user_id']}' 
                            data-firstname='{$user['first_name']}' 
                            data-lastname='{$user['last_name']}' 
                            data-phone='{$user['phone']}' 
                            data-email='{$user['email']}' 
                            data-username='{$user['username']}' 
                            data-role='{$user['role']}' 
                            data-status='{$user['status']}' 
                            data-adminedit='" . ($user['role'] === 'Admin' ? 'true' : 'false') . "'>Edit</button>";
                        echo "</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No users found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

    </div>


    <!-- Edit User Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm">
                        <input type="hidden" id="user_id" name="user_id">
                        <div class="mb-3">
                            <label for="first_name" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="last_name" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="Admin">Admin</option>
                                <option value="User">User</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addUserForm">
                        <div class="mb-3">
                            <label for="add_first_name" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="add_first_name" name="first_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="add_last_name" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="add_last_name" name="last_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="add_phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="add_phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="add_email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="add_email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="add_username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="add_username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="add_role" class="form-label">Role</label>
                            <select class="form-select" id="add_role" name="role" required>
                                <option value="Admin">Admin</option>
                                <option value="User">User</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="add_status" class="form-label">Status</label>
                            <select class="form-select" id="add_status" name="status" required>
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">Add User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/user_management.js"></script> <!-- Link to the new JS file -->



</body>

</html>