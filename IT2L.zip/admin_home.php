<!-- admin_honme.php -->
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="css/bootstrapstyle.css"> <!-- Link to Bootstrap styles -->
    <link rel="stylesheet" href="css/sidebar.css"> <!-- Link to Sidebar styles -->
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="content">
        <!-- Your main content -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>