<?php
session_start();
include 'db.php';

// Number of medicines to show per page
$limit = 12;

// Get the current page from the URL (if not present, default to page 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Calculate the starting point (offset) for the query
$offset = ($page - 1) * $limit;

// Get the sort column and order from the URL parameters, default to med_name and ASC
$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'med_name';
$sort_order = isset($_GET['order']) && $_GET['order'] == 'ASC' ? 'ASC' : 'DESC';
$allowed_columns = ['med_name', 'med_brand', 'med_manufacturer', 'med_category', 'med_form', 'med_dosage', 'med_price'];

// Validate the sort column to prevent SQL injection
if (!in_array($sort_column, $allowed_columns)) {
    $sort_column = 'med_name';
}

// Toggle the sort order for the next click
$next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';

// Count total medicines (for pagination)
$total_query = "SELECT COUNT(*) AS total FROM medicine WHERE med_archive = 1";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_medicines = $total_row['total'];
$total_pages = ceil($total_medicines / $limit);

// SQL query to fetch medicines sorted and paginated
$query = "SELECT med_id, med_name, med_brand, med_manufacturer, med_category, med_form, med_dosage, med_price 
          FROM medicine 
          WHERE med_archive = 1 
          ORDER BY $sort_column $sort_order 
          LIMIT $limit OFFSET $offset";

$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicine Cabinet</title>
    <link rel="stylesheet" href="css/bootstrapstyle.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/medicine_list.css">
</head>

<body>

    <div class="content" style="margin-left: 300px; margin-right: 50px; margin-top: 50px;">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <h2>Medicine Cabinet</h2>
            <div class="d-flex align-items-center">
                <input type="text" class="form-control me-2" placeholder="Search Medicines" aria-label="Search" style="min-width: 200px;">
                <a href="add_medicine.php" class="btn btn-info me-2" style="min-width: 150px;">Add Medicine</a>
                <a href="archived_medicines.php" class="btn btn-secondary" style="min-width: 170px;">Archived Medicines</a>
            </div>
        </div>

        <table class="table table-bordered table-hover">
            <caption class="caption-top">List of Available Medicines</caption>
            <thead>
                <tr>
                    <th><a href="?sort=med_name&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Medicine Name</a></th>
                    <th><a href="?sort=med_brand&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Brand</a></th>
                    <th><a href="?sort=med_manufacturer&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Manufacturer</a></th>
                    <th><a href="?sort=med_category&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Category</a></th>
                    <th><a href="?sort=med_form&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Form</a></th>
                    <th><a href="?sort=med_dosage&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Dosage</a></th>
                    <th><a href="?sort=med_price&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>">Price</a></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['med_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_brand']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_manufacturer']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_category']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_form']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_dosage']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_price']) . "</td>";
                        echo "<td><a href='edit_medicine.php?id=" . htmlspecialchars($row['med_id']) . "' class='btn btn-warning btn-sm'>Edit</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No medicines found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <!-- Pagination Links -->
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo $page - 1; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>">Previous</a></li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php if ($i == $page) echo 'active'; ?>"><a class="page-link" href="?page=<?php echo $i; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo $page + 1; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>">Next</a></li>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Add Medicine Button aligned to the right -->

    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/js/bootstrap.bundle.min.js"></script>

    <?php include 'sidebar.php'; ?>
</body>

</html>