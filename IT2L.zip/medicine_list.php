<?php
session_start();
include 'db.php';

// Number of medicines to show per page
$limit = 10;

// Get the current page from the URL (if not present, default to page 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Capture the search term from the URL
$search_term = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Calculate the starting point (offset) for the query
$offset = ($page - 1) * $limit;

// Get the sort column and order from the URL parameters
$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'med_name';
$sort_order = isset($_GET['order']) && $_GET['order'] == 'DESC' ? 'DESC' : 'ASC'; // Default to ascending
$allowed_columns = ['med_name', 'med_brand', 'med_manufacturer', 'med_category', 'med_form', 'med_dosage', 'med_price'];

// Validate the sort column to prevent SQL injection
if (!in_array($sort_column, $allowed_columns)) {
    $sort_column = 'med_name';
}

// Toggle the sort order for the next click
$next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';

// Count total medicines (for pagination), including the search term
$total_query = "SELECT COUNT(*) AS total FROM medicine WHERE med_archive = 1 AND (med_name LIKE '%$search_term%' OR med_brand LIKE '%$search_term%' OR med_manufacturer LIKE '%$search_term%' OR med_category LIKE '%$search_term%')";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_medicines = $total_row['total'];
$total_pages = ceil($total_medicines / $limit);

// SQL query to fetch medicines based on the search term, sorted and paginated
$query = "SELECT med_id, med_name, med_brand, med_manufacturer, med_category, med_form, med_dosage, med_price 
          FROM medicine 
          WHERE med_archive = 1 AND (med_name LIKE '%$search_term%' OR med_brand LIKE '%$search_term%' OR med_manufacturer LIKE '%$search_term%' OR med_category LIKE '%$search_term%') 
          ORDER BY $sort_column $sort_order 
          LIMIT $limit OFFSET $offset";

$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicine Cabinet</title>
    <link rel="stylesheet" href="css/bootstrapstyle.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/medicine_list.css">
</head>

<body>

    <div class="content" style="margin-left: 300px; margin-right: 50px; margin-top: 50px;">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <h2>Medicine Cabinet</h2>
            <form action="" method="GET" class="d-flex align-items-center">
                <input type="text" name="search" class="form-control me-2" placeholder="Search Medicines" aria-label="Search" style="min-width: 250px;" value="<?php echo htmlspecialchars($search_term); ?>">
                <input type="hidden" name="page" value="<?php echo $page; ?>">
                <input type="hidden" name="sort" value="<?php echo $sort_column; ?>">
                <input type="hidden" name="order" value="<?php echo $sort_order; ?>">
                <button type="submit" class="btn btn-outline-success me-2">Search</button>
                <a href="add_medicine.php" class="btn btn-info me-2" style="min-width: 150px;">Add Medicine</a>
                <a href="archived_medicines.php" class="btn btn-secondary" style="min-width: 170px;">Archived Medicines</a>
            </form>
        </div>

        <table class="table table-bordered table-hover">
            <caption class="caption-top">List of Available Medicines</caption>
            <thead>
                <tr>
                    <th><a href="?sort=med_name&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Medicine Name</a></th>
                    <th><a href="?sort=med_brand&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Brand</a></th>
                    <th><a href="?sort=med_manufacturer&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Manufacturer</a></th>
                    <th><a href="?sort=med_category&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Category</a></th>
                    <th><a href="?sort=med_form&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Form</a></th>
                    <th><a href="?sort=med_dosage&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Dosage</a></th>
                    <th><a href="?sort=med_price&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Price</a></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['med_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_brand']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_manufacturer']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_category']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_form']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_dosage']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['med_price']) . "</td>";
                        echo "<td><a href='edit_medicine.php?id=" . $row['med_id'] . "' class='btn btn-warning'>Edit</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No medicines found</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <nav aria-label="Page navigation">
            <ul class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search_term); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php include 'sidebar.php' ?>
</body>

</html>