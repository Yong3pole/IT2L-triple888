<?php

// login.php

session_start();

// Include database connection
include 'db.php'; // Adjust the path as needed

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM user WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Assuming you already retrieved the user record
        if ($password === $user['password']) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['role'] = $user['role']; // Store the role in session
            $_SESSION['success_message'] = "Login successful!"; // Set the success message

            // Success POP-UP
            echo "<script>
            alert('Login successful! Welcome, " . htmlspecialchars($user['first_name']) . "!');
            window.location.href = 'admin_home.php';
            </script>";
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "No user found with that username.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/bootstrapstyle.css"> <!-- Link to compiled CSS -->
    <style>
        /* Custom styles for the login box */
        .login-box {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="login-box">
            <h2 class="text-center">Login</h2>
            <?php if (isset($error)) {
                echo "<div class='alert alert-danger'>$error</div>";
            } ?>
            <form action="login.php" method="post" class="mt-4">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingInput" name="username" placeholder="Enter username" required>
                    <label for="floatingInput">Username</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="floatingInput" name="password" placeholder="Enter password" required>
                    <label for="floatingInput">Password</label>
                </div>
                <button type="submit" class="btn btn-warning w-100">LOGIN</button>
            </form>
        </div>
    </div>
</body>

</html>