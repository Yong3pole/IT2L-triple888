<?php
// sidebar.php
include 'db.php'; // Make sure this points to your db connection file


if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT first_name, last_name, role FROM user WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $fullName = $user['first_name'] . ' ' . $user['last_name'];
        $role = $user['role'];
    } else {
        $fullName = 'User';
        $role = 'Role';
    }
} else {
    $fullName = 'Guest';
    $role = 'Role';
}
?>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="images/triple888.jpg" alt="Triple 888 Pharmacy Logo" class="sidebar-logo">
        <h4><?php echo strtoupper(htmlspecialchars($fullName)); ?></h4>
        <p><?php echo strtoupper(htmlspecialchars($role)); ?></p>
    </div>
    <a href="admin_home.php">Dashboard</a>
    <a href="product_list.php">Product List</a>
    <a href="inventory.php">Inventory</a>
    <a href="user_management.php">User Management</a>
    <a href="admin_sales.php">Sales</a>
    <div class="logout-container">
        <a href="login.php" class="btn logout-btn">Logout</a>
    </div>
</div>