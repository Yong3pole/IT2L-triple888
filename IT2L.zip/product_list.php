<?php
session_start();
include 'db.php';

if (isset($_SESSION['success_addprod'])) {
    echo "<div class='alert alert-success text-center' style='position: absolute; left: 50%; transform: translateX(-50%); z-index: 1000; width: 50%;'>
            " . $_SESSION['success_addprod'] . "
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
          </div>";
    unset($_SESSION['success_addprod']);
}

// Display success message for editing product
if (isset($_SESSION['success_editprod'])) {
    echo "<div class='alert alert-success text-center' style='position: absolute; left: 50%; transform: translateX(-50%); z-index: 1000; width: 50%;'>
            " . $_SESSION['success_editprod'] . "
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
          </div>";
    unset($_SESSION['success_editprod']);
}

// Display error message for editing product
if (isset($_SESSION['error_editprod'])) {
    echo "<div class='alert alert-danger text-center' style='position: absolute; left: 50%; transform: translateX(-50%); z-index: 1000; width: 50%;'>
            " . $_SESSION['error_editprod'] . "
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
          </div>";
    unset($_SESSION['error_editprod']);
}


// Number of medicines to show per page
$limit = 10;

// Get the current page from the URL (if not present, default to page 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Capture the search term from the URL
$search_term = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Calculate the starting point (offset) for the query
$offset = ($page - 1) * $limit;

// Get the sort column and order from the URL parameters
$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'prod_name';
$sort_order = isset($_GET['order']) && $_GET['order'] == 'DESC' ? 'DESC' : 'ASC'; // Default to ascending
$allowed_columns = ['prod_name', 'prod_brand', 'prod_manufacturer', 'prod_category', 'prod_form', 'prod_dosage', 'prod_price'];

// Validate the sort column to prevent SQL injection
if (!in_array($sort_column, $allowed_columns)) {
    $sort_column = 'prod_name';
}

// Toggle the sort order for the next click
$next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';

// Count total medicines (for pagination), including the search term
$total_query = "SELECT COUNT(*) AS total FROM product WHERE prod_archive = 1 AND (prod_name LIKE '%$search_term%' OR prod_brand LIKE '%$search_term%' OR prod_manufacturer LIKE '%$search_term%' OR prod_category LIKE '%$search_term%')";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_medicines = $total_row['total'];
$total_pages = ceil($total_medicines / $limit);

// SQL query to fetch medicines based on the search term, sorted and paginated
$query = "SELECT prod_id, prod_name, prod_brand, prod_manufacturer, prod_category, prod_form, prod_dosage, prod_price 
          FROM product 
          WHERE prod_archive = 1 AND (prod_name LIKE '%$search_term%' OR prod_brand LIKE '%$search_term%' OR prod_manufacturer LIKE '%$search_term%' OR prod_category LIKE '%$search_term%') 
          ORDER BY $sort_column $sort_order 
          LIMIT $limit OFFSET $offset";

$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/medicine_list.css">
    <script src="../bootstrap/js/bootstrap.min.js"></script>

</head>

<body>
    <div class="content" style="margin-left: 300px; margin-right: 50px; margin-top: 50px;">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <h2>Product List</h2>
            <form action="" method="GET" class="d-flex align-items-center">
                <input type="text" name="search" class="form-control me-2" placeholder="Search Product" aria-label="Search" style="min-width: 250px;" value="<?php echo htmlspecialchars($search_term); ?>">
                <input type="hidden" name="page" value="<?php echo $page; ?>">
                <input type="hidden" name="sort" value="<?php echo $sort_column; ?>">
                <input type="hidden" name="order" value="<?php echo $sort_order; ?>">
                <button type="submit" class="btn btn-outline-success me-2">Search</button>
                <button type="button" class="btn btn-success me-2" style="min-width: 150px;" data-bs-toggle="modal" data-bs-target="#addMedicineModal">Add Product</button>
                <a href="archived_product.php" class="btn btn-secondary" style="min-width: 170px;">Archived Products</a>
            </form>
        </div>

        <table class="table table-bordered table-hover">
            <caption class="caption-top">List of Available Products</caption>
            <thead>
                <tr>
                    <th><a href="?sort=prod_name&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Product Name</a></th>
                    <th><a href="?sort=prod_brand&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Brand</a></th>
                    <th><a href="?sort=prod_manufacturer&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Manufacturer</a></th>
                    <th><a href="?sort=prod_category&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Category</a></th>
                    <th><a href="?sort=prod_form&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Form</a></th>
                    <th><a href="?sort=prod_dosage&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Dosage</a></th>
                    <th><a href="?sort=prod_price&order=<?php echo $next_sort_order; ?>&page=<?php echo $page; ?>&search=<?php echo urlencode($search_term); ?>">Price</a></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['prod_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['prod_brand']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['prod_manufacturer']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['prod_category']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['prod_form']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['prod_dosage']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['prod_price']) . "</td>";
                        echo "<td>
                    <button type='button' class='btn btn-info edit-btn' 
                        data-bs-toggle='modal' 
                        data-bs-target='#editMedicineModal' 
                        data-med-id='" . htmlspecialchars($row['prod_id']) . "'
                        data-med-name='" . htmlspecialchars($row['prod_name']) . "'
                        data-med-brand='" . htmlspecialchars($row['prod_brand']) . "'
                        data-med-manufacturer='" . htmlspecialchars($row['prod_manufacturer']) . "'
                        data-med-category='" . htmlspecialchars($row['prod_category']) . "'
                        data-med-form='" . htmlspecialchars($row['prod_form']) . "'
                        data-med-dosage='" . htmlspecialchars($row['prod_dosage']) . "'
                        data-med-price='" . htmlspecialchars($row['prod_price']) . "'>
                        Edit
                    </button>
                </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No medicines found</td></tr>";
                }
                ?>
            </tbody>

        </table>


        <!-- Add Product Modal -->
        <div class="modal fade" id="addMedicineModal" tabindex="-1" aria-labelledby="addMedicineModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addMedicineModalLabel">Add New Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="add_product.php" method="POST">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="prod_name" class="form-label">Product Name</label>
                                <input type="text" class="form-control" id="prod_name" name="prod_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="prod_brand" class="form-label">Brand</label>
                                <input type="text" class="form-control" id="prod_brand" name="prod_brand" required>
                            </div>
                            <div class="mb-3">
                                <label for="prod_manufacturer" class="form-label">Manufacturer</label>
                                <input type="text" class="form-control" id="prod_manufacturer" name="prod_manufacturer" required>
                            </div>
                            <div class="mb-3">
                                <label for="prod_category" class="form-label">Category</label>
                                <input type="text" class="form-control" id="prod_category" name="prod_category" required>
                            </div>
                            <div class="mb-3">
                                <label for="prod_form" class="form-label">Form (e.g., Tablet, Syrup)</label>
                                <input type="text" class="form-control" id="prod_form" name="prod_form" required>
                            </div>
                            <div class="mb-3">
                                <label for="prod_dosage" class="form-label">Dosage</label>
                                <input type="text" class="form-control" id="prod_dosage" name="prod_dosage" required>
                            </div>
                            <div class="mb-3">
                                <label for="prod_price" class="form-label">Price</label>
                                <input type="number" step="0.01" class="form-control" id="prod_price" name="prod_price" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Product Modal -->
        <div class="modal fade" id="editMedicineModal" tabindex="-1" aria-labelledby="editMedicineModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editMedicineModalLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="update_product.php" method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="prod_id" id="edit_prod_id">
                            <div class="mb-3">
                                <label for="edit_prod_name" class="form-label">Product Name</label>
                                <input type="text" class="form-control" id="edit_prod_name" name="prod_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit_prod_brand" class="form-label">Brand</label>
                                <input type="text" class="form-control" id="edit_prod_brand" name="prod_brand" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit_prod_manufacturer" class="form-label">Manufacturer</label>
                                <input type="text" class="form-control" id="edit_prod_manufacturer" name="prod_manufacturer" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit_prod_category" class="form-label">Category</label>
                                <input type="text" class="form-control" id="edit_prod_category" name="prod_category" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit_prod_form" class="form-label">Form</label>
                                <input type="text" class="form-control" id="edit_prod_form" name="prod_form" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit_prod_dosage" class="form-label">Dosage</label>
                                <input type="text" class="form-control" id="edit_prod_dosage" name="prod_dosage" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit_prod_price" class="form-label">Price</label>
                                <input type="number" step="0.01" class="form-control" id="edit_prod_price" name="prod_price" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- pagination -->
        <nav aria-label="Page navigation">
            <ul class="pagination">

                <!-- Previous Page Button (<) -->
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search_term); ?>" aria-label="Previous">
                            <span aria-hidden="true">Previous</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <a class="page-link"><span aria-hidden="true">Previous</span></a>
                    </li>
                <?php endif; ?>

                <!-- Page Numbers -->
                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search_term); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <!-- Next Page Button (>) -->
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search_term); ?>" aria-label="Next">
                            <span aria-hidden="true">Next</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <a class="page-link"><span aria-hidden="true">Next</span></a>
                    </li>
                <?php endif; ?>

            </ul>
        </nav>


    </div>
    <?php include 'sidebar.php' ?>


    <!-- script for populating the text fields in edit product modal -->
    <script>
        const editButtons = document.querySelectorAll('.edit-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const medId = this.getAttribute('data-med-id');
                const medName = this.getAttribute('data-med-name');
                const medBrand = this.getAttribute('data-med-brand');
                const medManufacturer = this.getAttribute('data-med-manufacturer');
                const medCategory = this.getAttribute('data-med-category');
                const medForm = this.getAttribute('data-med-form');
                const medDosage = this.getAttribute('data-med-dosage');
                const medPrice = this.getAttribute('data-med-price');

                document.getElementById('edit_prod_id').value = medId;
                document.getElementById('edit_prod_name').value = medName;
                document.getElementById('edit_prod_brand').value = medBrand;
                document.getElementById('edit_prod_manufacturer').value = medManufacturer;
                document.getElementById('edit_prod_category').value = medCategory;
                document.getElementById('edit_prod_form').value = medForm;
                document.getElementById('edit_prod_dosage').value = medDosage;
                document.getElementById('edit_prod_price').value = medPrice;
            });
        });
    </script>
</body>

</html>