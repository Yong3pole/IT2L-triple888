<?php
// update_user.php

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = $_POST['user_id'];
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    // Prepare the update statement
    $stmt = $conn->prepare("UPDATE user SET first_name = ?, last_name = ?, phone = ?, email = ?, username = ?, role = ?, status = ? WHERE user_id = ?");

    // Ensure to bind parameters correctly; notice the data types for each parameter
    $stmt->bind_param("ssssssii", $firstName, $lastName, $phone, $email, $username, $role, $status, $userId);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        // Check for affected rows to ensure it was a valid update
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No rows updated.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
