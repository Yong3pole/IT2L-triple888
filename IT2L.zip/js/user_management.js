const editModal = document.getElementById('editModal');
editModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    document.getElementById('user_id').value = button.getAttribute('data-id');
    document.getElementById('first_name').value = button.getAttribute('data-firstname');
    document.getElementById('last_name').value = button.getAttribute('data-lastname');
    document.getElementById('phone').value = button.getAttribute('data-phone');
    document.getElementById('email').value = button.getAttribute('data-email');
    document.getElementById('username').value = button.getAttribute('data-username');
    document.getElementById('role').value = button.getAttribute('data-role');
    document.getElementById('status').value = button.getAttribute('data-status');
});

document.getElementById('editUserForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch('update_user.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const modal = bootstrap.Modal.getInstance(editModal);
                modal.hide(); // Close the modal
                location.reload(); // Reload the table to reflect changes
            } else {
                alert('Failed to update user'); // Optional: Show error if update fails
            }
        })
        .catch(error => {
            console.error('Error:', error); // Log any errors
            alert('An error occurred while updating the user.');
        });
});

// user_management.js

document.addEventListener('DOMContentLoaded', function () {
    const editModal = document.getElementById('editModal');
    editModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget; // Button that triggered the modal
        const userId = button.getAttribute('data-id');
        const firstName = button.getAttribute('data-firstname');
        const lastName = button.getAttribute('data-lastname');
        const phone = button.getAttribute('data-phone');
        const email = button.getAttribute('data-email');
        const username = button.getAttribute('data-username');
        const role = button.getAttribute('data-role');
        const status = button.getAttribute('data-status');

        // Populate the form with user data
        document.getElementById('user_id').value = userId;
        document.getElementById('first_name').value = firstName;
        document.getElementById('last_name').value = lastName;
        document.getElementById('phone').value = phone;
        document.getElementById('email').value = email;
        document.getElementById('username').value = username;
        document.getElementById('role').value = role;
        document.getElementById('status').value = status;

        // If the user role is Admin, disable the role and status fields
        if (role === 'Admin') {
            document.getElementById('role').setAttribute('disabled', true);
            document.getElementById('status').setAttribute('disabled', true);
        } else {
            document.getElementById('role').removeAttribute('disabled');
            document.getElementById('status').removeAttribute('disabled');
        }
    });

    // Reset the modal when it's hidden to ensure fields are re-enabled
    editModal.addEventListener('hidden.bs.modal', function () {
        document.getElementById('role').removeAttribute('disabled');
        document.getElementById('status').removeAttribute('disabled');
    });
});


document.getElementById('addUserForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch('add_user.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const modal = bootstrap.Modal.getInstance(document.getElementById('addUserModal'));
                modal.hide(); // Close the modal
                location.reload(); // Reload the table to reflect changes
            } else {
                alert('Failed to add user'); // Optional: Show error if adding fails
            }
        })
        .catch(error => {
            console.error('Error:', error); // Log any errors
            alert('An error occurred while adding the user.');
        });
});


