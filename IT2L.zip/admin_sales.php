<?php

//admin_sales.php

session_start();
include 'db.php';  // Include the database connection file

// Function to get product name by product ID
function getProductName($product_id)
{
    global $conn;
    $query = "SELECT prod_name FROM product WHERE prod_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['prod_name'];
    } else {
        return "Unknown Product";
    }
}

// If AJAX request (startDate and endDate are passed via GET parameters), return JSON response
if (isset($_GET['startDate']) && isset($_GET['endDate'])) {
    $startDate = $_GET['startDate'];
    $endDate = $_GET['endDate'];

    // Query to fetch sales data within the specified date range
    $salesQuery = "
        SELECT s.transaction_id, t.transaction_date, t.total_purchase, t.customer_id, t.payment_method
        FROM sales s
        JOIN transactions t ON s.transaction_id = t.transaction_id
        WHERE t.transaction_date BETWEEN ? AND ?
    ";

    $salesStmt = $conn->prepare($salesQuery);
    $salesStmt->bind_param("ss", $startDate, $endDate);  // Bind parameters to prevent SQL injection
    $salesStmt->execute();
    $salesResult = $salesStmt->get_result();
    $salesData = $salesResult->fetch_all(MYSQLI_ASSOC);  // Fetch the sales data

    // Calculate total sales and total number of transactions
    $totalSales = array_sum(array_column($salesData, 'total_purchase'));  // Sum up the total purchases
    $totalTransactions = count($salesData);  // Count the number of transactions

    // Query to find the most sold product in the specified date range
    $mostSoldProductQuery = "
        SELECT si.prod_id, SUM(si.quantity_sold) AS total_quantity
        FROM sales_items si
        JOIN sales s ON si.sale_id = s.sale_id
        JOIN transactions t ON s.transaction_id = t.transaction_id
        WHERE t.transaction_date BETWEEN ? AND ?
        GROUP BY si.prod_id
        ORDER BY total_quantity DESC
        LIMIT 1
    ";

    $mostSoldProductStmt = $conn->prepare($mostSoldProductQuery);
    $mostSoldProductStmt->bind_param("ss", $startDate, $endDate);
    $mostSoldProductStmt->execute();
    $mostSoldProductResult = $mostSoldProductStmt->get_result();
    $mostSoldProduct = $mostSoldProductResult->fetch_assoc();

    // If a product is found, retrieve its name; otherwise, return null
    $mostSoldProductName = $mostSoldProduct ? getProductName($mostSoldProduct['prod_id']) : "N/A";

    // Send the response as JSON
    echo json_encode([
        'sales' => $salesData,
        'totalSales' => $totalSales,
        'totalTransactions' => $totalTransactions,
        'mostSoldProduct' => $mostSoldProductName
    ]);
    exit; // Terminate the script after sending the JSON response
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Overview</title>
    <!-- Add Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="css/sidebar.css"> <!-- Link to Sidebar styles -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        /* Adjust body to avoid overlap with fixed navbar */
        h1 {
            text-align: center;
        }

        .container {
            max-height: 55vh;
            max-width: 1000px;
            margin: 0 auto;
        }

        .filter-group {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        input[type="date"] {
            padding: 10px;
            width: 45%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .result-group {
            display: flex;
            justify-content: space-evenly;
            margin: 20px 0;
        }

        .result-box {
            background-color: #d8e5cc;
            /* Light background color */
            border: 1px solid #ccc;
            /* Border around each box */
            border-radius: 8px;
            /* Rounded corners */
            padding: 20px;
            /* Padding inside the boxes */
            flex: 1;
            /* Make each box take equal space */
            margin: 0 10px;
            /* Margin between boxes */
            text-align: center;
            /* Center align text */
        }

        .result-box h2 {
            font-size: 1.0rem;
            /* Control the size of the header text */
            margin-bottom: 10px;
            /* Margin below the header */
        }

        .result-box p {
            font-size: 1.2rem;
            /* Control the size of the paragraph text */
            font-weight: bold;
            /* Make the text bold */
        }

        .table-responsive {
            max-height: 55vh;
            /* Default max height relative to viewport height */
            overflow-y: auto;
            /* Enable vertical scrolling */
            border: 1px solid #ccc;
            /* Optional: Add a border around the table */
            margin-top: 20px;
            /* Space between result boxes and the table */
        }

        table {
            width: 100%;
            /* Make the table take full width */
            border-collapse: collapse;
            /* Remove space between cells */
        }

        th,
        td {
            padding: 12px;
            /* Add padding to table cells */
            text-align: left;
            /* Align text to the left */
            border-bottom: 1px solid #ddd;
            /* Add a border below each row */
        }

        th {
            background-color: #007bff;
            /* Background color for headers */
            color: white;
            /* Text color for headers */
            position: sticky;
            /* Make the header sticky */
            top: 0;
            /* Stick to the top of the scrolling container */
            z-index: 10;
            /* Ensure the header is above the table content */
        }


        /* Media queries for different screen sizes */
        @media (max-width: 768px) {
            .table-responsive {
                max-height: 50vh;
                /* Reduce max height for smaller screens */
            }
        }

        @media (max-width: 576px) {
            .table-responsive {
                max-height: 40vh;
                /* Further reduce max height for very small screens */
            }
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php' ?>

    <div class="container mt-3">
        <h1>SALES OVERVIEW</h1>

        <!-- Filter section with date range -->
        <div class="filter-group mt-3">
            <input type="date" id="startDate" value="<?= date('Y-m-d'); ?>">
            <input type="date" id="endDate" value="<?= date('Y-m-d'); ?>">
            <button onclick="fetchSalesData()">Generate</button>
        </div>

        <!-- Result section to display total sales, total transactions, and most sold product -->
        <div class="result-group">
            <div class="result-box">
                <h2>TOTAL SALES</h2>
                <p id="totalSales">$0.00</p>
            </div>
            <div class="result-box">
                <h2>TOTAL TRANSACTIONS</h2>
                <p id="totalTransactions">0</p>
            </div>
            <div class="result-box">
                <h2>MOST SOLD PRODUCT</h2>
                <p id="mostSoldProduct">N/A</p>
            </div>
        </div>

        <!-- Table to display detailed sales data -->
        <div class="table-responsive">
            <table id="salesTable">
                <thead>
                    <tr>
                        <th>Transaction ID</th>
                        <th>Date</th>
                        <th>Customer ID</th>
                        <th>Total Purchase</th>
                        <th>Payment Method</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Sales data rows will go here -->
                </tbody>
            </table>
        </div>
        <button onclick="printReport()" class="btn btn-success mt-4">Print Report</button>

    </div>


    <!-- Add Bootstrap JS and dependencies -->
    <script src="jquery/jquery-3.7.1.min.js"></script>
    <script src="node_modules/@popperjs/core/lib/popper-lite.js"></script>
    <script src="bootstrap/js/bootstrap.bundle.js"></script>

    <script>
        // Fetch sales data based on selected date range
        function fetchSalesData() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;

            // Fetch data from the PHP backend
            fetch(`admin_sales.php?startDate=${startDate}&endDate=${endDate}`)
                .then(response => response.json())
                .then(data => {
                    // Update total sales, total transactions, and most sold product
                    document.getElementById('totalSales').innerText = `₱${data.totalSales.toFixed(2)}`;
                    document.getElementById('totalTransactions').innerText = data.totalTransactions;
                    document.getElementById('mostSoldProduct').innerText = data.mostSoldProduct;

                    // Populate the table with sales data
                    const salesTableBody = document.querySelector('#salesTable tbody');
                    salesTableBody.innerHTML = ''; // Clear the table

                    data.sales.forEach(sale => {
                        const row = `<tr>
                        <td>${sale.transaction_id}</td>
                        <td>${sale.transaction_date}</td>
                        <td>${sale.customer_id}</td>
                        <td>₱${parseFloat(sale.total_purchase).toFixed(2)}</td>
                        <td>${sale.payment_method}</td>
                    </tr>`;
                        salesTableBody.insertAdjacentHTML('beforeend', row);
                    });
                })
                .catch(error => {
                    console.error('Error fetching sales data:', error);
                });
        }

        // Call the function on page load to generate today's report
        window.onload = function() {
            const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
            document.getElementById('startDate').value = today; // Set start date to today
            document.getElementById('endDate').value = today; // Set end date to today
            fetchSalesData(); // Fetch today's sales data
        };

        function printReport() {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
        <html>
            <head>
                <title>Sales Report</title>
                <link rel="stylesheet" href="../css/bootstrapstyle.css">
                <style>
                    table {
                        width: 100%;
                        border-collapse: collapse;
                    }
                    th, td {
                        padding: 12px;
                        text-align: left;
                        border: 1px solid #ddd;
                    }
                    th {
                        background-color: #007bff;
                        color: white;
                    }
                </style>
            </head>
            <body>
                <h1>Sales Report</h1>
                <div>
                    <h2>Total Sales: ${document.getElementById('totalSales').innerText}</h2>
                    <h2>Total Transactions: ${document.getElementById('totalTransactions').innerText}</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Date</th>
                            <th>Customer ID</th>
                            <th>Total Purchase</th>
                            <th>Payment Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${Array.from(document.querySelectorAll('#salesTable tbody tr'))
                            .map(row => `<tr>${row.innerHTML}</tr>`)
                            .join('')}
                    </tbody>
                </table>
            </body>
        </html>
    `);
            printWindow.document.close();
            printWindow.print();
        }
    </script>

</body>

</html>