<?php
// Include database connection
include 'db.php';
?>

<!-- Checkout Sidebar (Right side) -->
<div class="col-md-4">
    <div class="checkout-sidebar">
        <h3>Order</h3>
        <!-- Apply Discount Button -->
        <div class="d-flex mb-3">
            <button class="btn btn-info w-100 me-2" id="apply-discount-btn" data-bs-toggle="modal" data-bs-target="#discountModal">Apply Discount</button>
            <button class="btn btn-secondary w-100" id="clear-discount-btn">Clear Discount</button>
        </div>
        <div id="cart-items" class="cart-items-scroll">
            <p>No items added.</p>
        </div>

        <div class="discount-row">
            <span>Discount:</span>
            <span>₱ <span id="discount-amount">0.00</span></span>
        </div>
        <div class="subtotal-row">
            <span>Subtotal:</span>
            <span>₱ <span id="subtotal-amount">0.00</span></span>
        </div>

        <div class="total-row">
            <span>Total:</span>
            <span class="total-amount">₱ <span id="total-price">0.00</span></span>
        </div>
        <button class="btn btn-danger w-100 mt-3" id="clear-cart-btn">Clear Items</button>
        <!-- Checkout Form -->
        <form id="checkout-form" method="POST" action="save_transaction.php">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
            <input type="hidden" name="total_purchase" id="total-purchase" value="0.00">

            <!-- Hidden fields to capture customer details -->
            <input type="hidden" name="customer_name" id="customer-name-hidden">
            <input type="hidden" name="customer_contact" id="customer-contact-hidden">
            <input type="hidden" name="discount_id" id="discount-id-hidden">

            <button class="btn btn-success w-100 mt-3" id="complete-purchase-btn" type="submit" disabled>Complete Purchase</button>
        </form>
    </div>
</div>

<script>
    // Initialize an array to hold cart items
    let cartItems = [];
    let discountApplied = false; // Flag to track if discount has been applied
    let discountAmount = 0; // To store the discount amount

    document.addEventListener('DOMContentLoaded', function() {
        ///////////// Add event listeners to all "Add to Cart" buttons ////////////////////
        const addToCartButtons = document.querySelectorAll('.add-to-cart');
        addToCartButtons.forEach(button => {
            button.addEventListener('click', function() {
                const itemId = this.getAttribute('data-id');
                const itemName = this.getAttribute('data-name');
                const itemPrice = parseFloat(this.getAttribute('data-price'));

                // Check if item is already in the cart
                const existingItem = cartItems.find(item => item.id === itemId);
                if (existingItem) {
                    existingItem.quantity += 1; // Increase quantity if item is already in the cart
                } else {
                    // Add new item to cart
                    cartItems.push({
                        id: itemId,
                        name: itemName,
                        price: itemPrice,
                        quantity: 1
                    });
                }

                updateCartDisplay();
            });
        });

        // Add event listener for the "Clear Items" button
        const clearCartButton = document.getElementById('clear-cart-btn');
        clearCartButton.addEventListener('click', function() {
            cartItems = []; // Clear the cart items array
            updateCartDisplay(); // Update the cart display
        });
    });

    ///////////////// UPDATING THE CART //////////////////////
    function updateCartDisplay() {
        const cartItemsContainer = document.getElementById('cart-items');
        const checkoutForm = document.getElementById('checkout-form');

        // Clear current display
        cartItemsContainer.innerHTML = '';
        const existingCartItemInputs = checkoutForm.querySelectorAll('.cart-item-input');
        existingCartItemInputs.forEach(input => input.remove());

        if (cartItems.length === 0) {
            cartItemsContainer.innerHTML = '<p>No items added.</p>';
            document.getElementById('complete-purchase-btn').setAttribute('disabled', true);
            document.getElementById('subtotal-amount').innerText = '0.00';
            document.getElementById('total-price').innerText = '0.00';
            document.getElementById('total-purchase').value = '0.00';
            document.getElementById('discount-amount').innerText = '0.00'; // Reset discount display
            discountApplied = false; // Reset discount flag
            return;
        }

        let subtotal = 0;
        cartItems.forEach(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;

            // Create hidden inputs for each item
            const itemInput = document.createElement('input');
            itemInput.type = 'hidden';
            itemInput.name = 'cart_items[]';
            itemInput.value = JSON.stringify({
                id: item.id,
                name: item.name,
                price: item.price,
                quantity: item.quantity
            });
            itemInput.className = 'cart-item-input';
            checkoutForm.appendChild(itemInput);

            // Display cart item
            cartItemsContainer.innerHTML += `
            <div class="cart-item d-flex justify-content-between align-items-center border p-2 mb-2">
                <div>
                    <strong>${item.name}</strong> - ₱ ${item.price.toFixed(2)} x ${item.quantity} = ₱ ${itemTotal.toFixed(2)} (ID: ${item.id})
                </div>
                <button class="btn btn-danger btn-sm remove-item" data-id="${item.id}">Remove</button>
            </div>`;
        });

        // Update subtotal
        document.getElementById('subtotal-amount').innerText = subtotal.toFixed(2);

        // If a discount is applied, recalculate the discount and update total
        if (discountApplied) {
            applyDiscount(); // Reapply discount based on updated subtotal
        } else {
            document.getElementById('total-price').innerText = subtotal.toFixed(2);
            document.getElementById('total-purchase').value = subtotal.toFixed(2);
        }

        document.getElementById('complete-purchase-btn').removeAttribute('disabled');

        // Debugging: Log the cart items to console
        console.log(cartItems);
    }

    /////////////// Remove item functionality //////////////////
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('remove-item')) {
            const itemId = event.target.getAttribute('data-id');
            cartItems = cartItems.filter(item => item.id !== itemId); // Remove item from cart
            updateCartDisplay(); // Update display
        }
    });

    //////////// Apply Discount Button //////////////////
    document.getElementById('apply-discount-confirm').addEventListener('click', function() {
        const name = document.getElementById('senior-name').value;
        const contact = document.getElementById('senior-contact').value;
        const discountId = document.getElementById('discount-id').value;

        // Basic validation
        if (name === '' || contact === '' || discountId === '') {
            alert('Please fill in all fields for the discount.');
            return; // Don't proceed further if validation fails
        }

        // Store customer details in hidden inputs
        document.getElementById('customer-name-hidden').value = name;
        document.getElementById('customer-contact-hidden').value = contact;
        document.getElementById('discount-id-hidden').value = discountId;

        discountApplied = true; // Set the discount flag
        applyDiscount(); // Apply discount

        // Close the modal after applying the discount
        const discountModal = document.getElementById('discountModal');
        const bootstrapModal = bootstrap.Modal.getInstance(discountModal); // Get the current modal instance
        if (bootstrapModal) {
            bootstrapModal.hide();
        }

        // Clear the input fields in the modal
        document.getElementById('senior-name').value = '';
        document.getElementById('senior-contact').value = '';
        document.getElementById('discount-id').value = '';
    });

    ////////////// Function to apply the discount ///////////////////
    function applyDiscount() {
        const subtotal = parseFloat(document.getElementById('subtotal-amount').innerText);
        discountAmount = subtotal * 0.12; // 12% discount
        const totalWithDiscount = subtotal - discountAmount;

        // Update the displayed discount and total price
        document.getElementById('discount-amount').innerText = discountAmount.toFixed(2);
        document.getElementById('total-price').innerText = totalWithDiscount.toFixed(2);
        document.getElementById('total-purchase').value = totalWithDiscount.toFixed(2);
    }

    ////////////////// CLEAR DISCOUNT ////////////////////
    document.getElementById('clear-discount-btn').addEventListener('click', function() {
        // Reset the discount amount
        document.getElementById('discount-amount').innerText = '0.00';

        // Reset the total price to the subtotal
        const subtotal = parseFloat(document.getElementById('subtotal-amount').innerText);
        document.getElementById('total-price').innerText = subtotal.toFixed(2);
        document.getElementById('total-purchase').value = subtotal.toFixed(2);

        // Mark that discount is no longer applied
        discountApplied = false;
        discountAmount = 0; // Reset discount amount

        // Optionally: Log to console for debugging
        console.log('Discount cleared. Total reset to:', subtotal.toFixed(2));
    });
</script>