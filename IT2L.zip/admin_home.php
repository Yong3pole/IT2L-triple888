<!-- admin_honme.php -->
<?php session_start();

include 'db.php';

// Query to get the total number of medicines in stock
$medicines_query = "SELECT COUNT(*) as total_medicines FROM product WHERE prod_archive = 1";
$result = $conn->query($medicines_query);
$total_medicines = $result->fetch_assoc()['total_medicines'];

// Query for total sales today
$sales_query = "SELECT SUM(total_purchase) AS total_sales FROM transactions WHERE DATE(transaction_date) = CURDATE()";
$sales_result = mysqli_query($conn, $sales_query);
$sales_data = mysqli_fetch_assoc($sales_result);
$total_sales_today = $sales_data['total_sales'] ? number_format($sales_data['total_sales'], 2) : '0.00';

// Query for total transactions today
$transactions_query = "SELECT COUNT(*) AS total_transactions FROM transactions WHERE DATE(transaction_date) = CURDATE()";
$transactions_result = mysqli_query($conn, $transactions_query);
$transactions_data = mysqli_fetch_assoc($transactions_result);
$total_transactions_today = $transactions_data['total_transactions'] ? $transactions_data['total_transactions'] : 0;

// Query for medicines nearing expiry
$expiry_query = "SELECT * FROM batch WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH)";
$expiry_result = mysqli_query($conn, $expiry_query);
$near_expiry_medicines = mysqli_fetch_all($expiry_result, MYSQLI_ASSOC);
$total_near_expiry = count($near_expiry_medicines);

// Query for expired medicines
$expired_query = "SELECT * FROM batch WHERE expiry_date < CURDATE()";
$expired_result = mysqli_query($conn, $expired_query);
$expired_medicines = mysqli_fetch_all($expired_result, MYSQLI_ASSOC);
$total_expired = count($expired_medicines);

// Function to get product details by prod_id
function getProductDetails($prod_id)
{
    global $conn; // Access the global database connection
    $query = "SELECT prod_name, prod_brand FROM product WHERE prod_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $prod_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        return $row; // Return the product details
    }

    return null; // Return null if no product found
}

// Main logic to fetch the most sold product today
$todayTransactionsQuery = "
    SELECT transaction_id
    FROM transactions
    WHERE transaction_date = CURDATE();
";

$todayTransactionsResult = $conn->query($todayTransactionsQuery);
$transactionIds = [];

while ($row = $todayTransactionsResult->fetch_assoc()) {
    $transactionIds[] = $row['transaction_id'];
}

// Only proceed if there are transaction IDs
if (!empty($transactionIds)) {
    // Constructing a dynamic query with placeholders
    $inClause = implode(',', array_fill(0, count($transactionIds), '?'));

    $saleIdsQuery = "
        SELECT sale_id
        FROM sales
        WHERE transaction_id IN ($inClause)
    ";

    $saleIdsStmt = $conn->prepare($saleIdsQuery);

    // Bind each transaction ID dynamically
    $types = str_repeat('i', count($transactionIds));
    $saleIdsStmt->bind_param($types, ...$transactionIds);
    $saleIdsStmt->execute();
    $saleIdsResult = $saleIdsStmt->get_result();

    $saleIds = [];
    while ($row = $saleIdsResult->fetch_assoc()) {
        $saleIds[] = $row['sale_id'];
    }

    // If there are sale IDs, fetch the most sold product
    if (!empty($saleIds)) {
        $inClauseSaleIds = implode(',', array_fill(0, count($saleIds), '?'));

        $mostSoldProductQuery = "
            SELECT si.prod_id, SUM(si.quantity_sold) AS total_quantity
            FROM sales_items si
            WHERE si.sale_id IN ($inClauseSaleIds)
            GROUP BY si.prod_id
            ORDER BY total_quantity DESC
            LIMIT 1
        ";

        $mostSoldProductStmt = $conn->prepare($mostSoldProductQuery);
        $mostSoldProductStmt->bind_param(str_repeat('i', count($saleIds)), ...$saleIds);
        $mostSoldProductStmt->execute();
        $mostSoldProductResult = $mostSoldProductStmt->get_result();
        $mostSoldProduct = $mostSoldProductResult->fetch_assoc();
    }
} else {
    // Handle the case where there are no transactions for today
    $mostSoldProduct = null;
}
// Fetch product details (name and brand)
$mostSoldProductDetails = $mostSoldProduct ? getProductDetails($mostSoldProduct['prod_id']) : null;

if ($mostSoldProductDetails) {
    $mostSoldProductInfo = $mostSoldProductDetails['prod_name'] . " (" . $mostSoldProductDetails['prod_brand'] . ")";
} else {
    $mostSoldProductInfo = "N/A";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="css/sidebar.css"> <!-- Link to Sidebar styles -->
    <style>

    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="content">
        <div class="container mt-5"> <!-- Use Bootstrap's margin top utility -->
            <div class="row">

                <!-- Total Sales Widget -->
                <div class="col-md-4 mt-5">
                    <div class="card text-center">
                        <div class="card-header" style="background-color: #a6f196;">
                            Total Sales for Today
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">₱ <?php echo $total_sales_today; ?></h5>
                            <p class="card-text">Total sales for today.</p>
                        </div>
                    </div>
                </div>

                <!-- Total Transactions Widget -->
                <div class="col-md-4 mt-5">
                    <div class="card text-center">
                        <div class="card-header" style="background-color: #a6f196;">
                            Total Transactions Today
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $total_transactions_today; ?></h5>
                            <p class="card-text">Total number of transactions today.</p>
                        </div>
                    </div>
                </div>

                <!-- Most Sold Product Widget -->
                <div class="col-md-4 mt-5">
                    <div class="card text-center">
                        <div class="card-header" style="background-color: #a6f196;">
                            Most Sold Product Today
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $mostSoldProductInfo; ?></h5>
                            <p class="card-text">The most sold product today.</p>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row mt-3">
                <!-- Total Near Expiry Medicines Widget -->
                <div class="col-md-4 mt-5">
                    <div class="card text-center">
                        <div class="card-header" style="background-color: #96d5f1;">
                            Total Near Expiry Medicines
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $total_near_expiry; ?></h5>
                            <p class="card-text">Medicines nearing their expiry date.</p>
                        </div>
                    </div>
                </div>

                <!-- Total Expired Medicines Widget -->
                <div class="col-md-4 mt-5">
                    <div class="card text-center">
                        <div class="card-header" style="background-color: #96d5f1;">
                            Total Expired Medicines
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $total_expired; ?></h5>
                            <p class="card-text">Medicines that have expired.</p>
                        </div>
                    </div>
                </div>

                <!-- Total Medicines Widget -->
                <div class="col-md-4 mt-5">
                    <div class="card text-center">
                        <div class="card-header" style="background-color: #96d5f1;">
                            Total Medicines in Stock
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $total_medicines; ?></h5>
                            <p class="card-text">Total number of medicines available.</p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Low Stock Products Widget -->

            <?php
            // Query to get products low in stock
            $lowStockQuery = "
                    SELECT p.prod_id, p.prod_name, p.prod_brand, i.quantity, i.threshold
                    FROM inventory i
                    JOIN product p ON i.prod_id = p.prod_id
                    WHERE i.quantity <= i.threshold
                ";

            $lowStockStmt = $conn->prepare($lowStockQuery);
            $lowStockStmt->execute();
            $lowStockResult = $lowStockStmt->get_result();

            // Store low stock products in an array
            $lowStockProducts = [];
            while ($row = $lowStockResult->fetch_assoc()) {
                $lowStockProducts[] = $row;
            }

            // Get the total number of low stock products
            $totalLowStock = count($lowStockProducts);


            ?>
            <!-- New Row for Products Low in Stock Widget -->
            <div class="row mt-3 justify-content-center"> <!-- Add justify-content-center here to center the row -->
                <div class="col-md-5 mt-5"> <!-- Use col-md-6 to make it take up half the width of the page -->
                    <div class="card text-center">
                        <div class="card-header">
                            Products Low in Stock
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $totalLowStock; ?> products low on stock</h5>
                            <ul>
                                <?php foreach ($lowStockProducts as $product): ?>
                                    <li>
                                        <?php echo $product['prod_name'] . " (" . $product['prod_brand'] . ") - " . $product['quantity'] . " units left"; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Continue adding rows for more widgets as needed -->
        </div>
    </div>

    <script src="node_modules/@popperjs/core/lib/popper-lite.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>

</body>

</html>