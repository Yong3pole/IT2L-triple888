<?php
// At the top of save_transaction.php
session_start();

// Include database connection
include 'db.php';

// Retrieve user ID and total purchase amount
$user_id = $_POST['user_id'];
$total_purchase = $_POST['total_purchase'];
$payment_method = 'Cash'; // Assuming a default payment method for now; modify as needed
$cart_items = isset($_POST['cart_items']) ? $_POST['cart_items'] : [];

// Capture customer details from hidden fields
$customer_name = $_POST['customer_name'];
$customer_contact = $_POST['customer_contact'];
$discount_id = $_POST['discount_id'];

// Start a transaction to ensure atomicity
$conn->begin_transaction();

try {
    // Insert customer details into the customer table only if they are not empty
    $customer_id = null; // Initialize customer_id variable
    if (!empty($customer_name) && !empty($customer_contact) && !is_null($discount_id)) {
        $insertCustomerQuery = "INSERT INTO customer (customer_name, customer_contact, discount_id) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insertCustomerQuery);
        $stmt->bind_param("ssi", $customer_name, $customer_contact, $discount_id);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting customer: " . $stmt->error);
        }

        // Retrieve the inserted customer ID
        $customer_id = $stmt->insert_id;
    } else {
        // Optionally handle the case where customer details are not provided
        error_log("Customer details are not provided; skipping insertion.");
    }

    // Insert a new transaction
    $stmt = $conn->prepare("INSERT INTO transactions (transaction_date, user_id, payment_method, total_purchase, customer_id) VALUES (NOW(), ?, ?, ?, ?)");
    // Bind customer_id; it can be null if customer details are not inserted
    $stmt->bind_param("isdi", $user_id, $payment_method, $total_purchase, $customer_id);
    if (!$stmt->execute()) {
        throw new Exception("Error inserting transaction: " . $stmt->error);
    }

    // Get the last inserted transaction ID
    $transaction_id = $stmt->insert_id;

    // Insert a new sale record linked to the transaction
    $sale_stmt = $conn->prepare("INSERT INTO sales (transaction_id) VALUES (?)");
    $sale_stmt->bind_param("i", $transaction_id);
    if (!$sale_stmt->execute()) {
        throw new Exception("Error inserting sale: " . $sale_stmt->error);
    }

    // Get the last inserted sale ID
    $sale_id = $sale_stmt->insert_id;

    // Iterate over cart items to save each sold item
    foreach ($cart_items as $item) {
        $item_data = json_decode($item, true); // Decode the JSON string to an associative array
        $item_id = $item_data['id'];  // This should correspond to the prod_id in the inventory
        $item_quantity = $item_data['quantity'];
        $item_price = $item_data['price'];

        // Save each item to the sales_items table
        $sales_item_stmt = $conn->prepare("INSERT INTO sales_items (sale_id, prod_id, quantity_sold, price_sold) VALUES (?, ?, ?, ?)");
        $sales_item_stmt->bind_param("iiid", $sale_id, $item_id, $item_quantity, $item_price);
        if (!$sales_item_stmt->execute()) {
            throw new Exception("Error inserting sales item: " . $sales_item_stmt->error);
        }

        // Update the inventory by reducing the quantity
        $update_inventory_stmt = $conn->prepare("UPDATE inventory SET quantity = quantity - ? WHERE prod_id = ?");
        $update_inventory_stmt->bind_param("ii", $item_quantity, $item_id);
        if (!$update_inventory_stmt->execute()) {
            throw new Exception("Error updating inventory: " . $update_inventory_stmt->error);
        }
    }

    // Commit the transaction
    $conn->commit();

    // After successful transaction processing
    $_SESSION['purchase_complete'] = "Transaction completed successfully!";
    header("Location: user_home.php"); // Redirect to the user home page
    exit();
} catch (Exception $e) {
    // Roll back the transaction in case of error
    $conn->rollback();
    error_log("Transaction failed: " . $e->getMessage());

    // Optionally, set an error message and redirect
    $_SESSION['purchase_complete'] = "Error processing transaction!";
    header("Location: user_home.php");
    exit();
}
