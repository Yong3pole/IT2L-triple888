<?php
session_start();
include 'db.php';

// Fetch inventory data
$inventoryQuery = "
    SELECT i.prod_id, p.prod_name, p.prod_brand, i.quantity, i.threshold 
    FROM inventory i
    JOIN product p ON i.prod_id = p.prod_id
";
$inventoryResult = $conn->query($inventoryQuery);

// Fetch batch data for expiry monitoring
$expiryQuery = "
    SELECT b.prod_id, p.prod_name, p.prod_brand, b.batch_number, b.expiry_date, b.batch_quantity, b.batch_status 
    FROM batch b
    JOIN product p ON b.prod_id = p.prod_id
";
$expiryResult = $conn->query($expiryQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS System - Inventory Monitoring</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="cashier_css/inventory.css">
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</head>

<body style="background-color: #d8e5cc;">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Triple 888 Pharmacy System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="user_home.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_sales.php">Sales</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="user_inventory.php">Inventory <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <!-- Stock Inventory Table (scrollable) -->
            <div class="col-md-6 scrollable-table">
                <h2>Stock Monitor</h2>
                <div class="table-responsive fixed-height">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Brand</th>
                                <th>Quantity</th>
                                <th>Threshold</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $inventoryResult->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['prod_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['prod_brand']); ?></td>
                                    <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                    <td><?php echo htmlspecialchars($row['threshold'] ?? ''); ?></td>
                                    <td>
                                        <?php if ($row['threshold'] !== null): ?>
                                            <?php if ($row['quantity'] < $row['threshold']): ?>
                                                <span class="text-danger">Low Stock</span>
                                            <?php else: ?>
                                                <span class="text-success">In Stock</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-success">In Stock</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Med Batch Expiry Monitor Table (static) -->
            <div class="col-md-6">
                <h2>Med Batch Expiry Monitor</h2>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Brand</th>
                                <th>Batch Number</th>
                                <th>Expiry Date</th>
                                <th>Batch Quantity</th>
                                <th>Batch Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $expiryResult->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['prod_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['prod_brand']); ?></td>
                                    <td><?php echo htmlspecialchars($row['batch_number']); ?></td>
                                    <td><?php echo htmlspecialchars($row['expiry_date']); ?></td>
                                    <td><?php echo htmlspecialchars($row['batch_quantity']); ?></td>
                                    <td>
                                        <?php if ($row['batch_status'] === null): ?>
                                            <a href="#" class="btn btn-danger">Action</a>
                                        <?php else: ?>
                                            <?php echo htmlspecialchars($row['batch_status']); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>


</body>

</html>